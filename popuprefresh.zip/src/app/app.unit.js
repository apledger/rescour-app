/**
 * Created with JetBrains WebStorm.
 * User: spencer
 * Date: 8/28/13
 * Time: 9:08 AM
 * To change this template use File | Settings | File Templates.
 */

'use strict';

describe('rescour.app', function() {

    beforeEach(function() {
        module('rescour.app');
    });

    it('should run a test', function() {
        expect(1).toBe(1);
    });
});