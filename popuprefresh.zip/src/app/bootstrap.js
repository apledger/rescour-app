/**
 * Created with JetBrains WebStorm.
 * User: apledger
 * Date: 4/24/13
 * Time: 9:43 PM
 * File:
 */


angular.bootstrap(document, ['rescour.app']);