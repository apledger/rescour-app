app
===

Requirements:
- Ruby
- SASS/SCSS
- grunt-cli
- node / npm

1. Clone repo
2. npm install
3. from /src -> bower install
4. grunt (dev/local)
